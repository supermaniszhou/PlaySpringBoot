CREATE TRIGGER TR_SYS_MENU
  BEFORE INSERT
  ON SYS_MENU
  FOR EACH ROW
  declare tempnum number; begin select SEQ_SYS_MENU.nextval into tempnum from dual; :new.ID :=tempnum; end;
/

