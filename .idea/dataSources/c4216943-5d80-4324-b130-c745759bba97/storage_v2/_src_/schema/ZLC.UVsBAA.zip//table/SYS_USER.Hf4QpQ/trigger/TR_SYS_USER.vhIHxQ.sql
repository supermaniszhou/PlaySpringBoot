CREATE TRIGGER TR_SYS_USER
  BEFORE INSERT
  ON SYS_USER
  FOR EACH ROW
  declare tempnum number; begin select SEQ_sys_user.nextval into tempnum from dual; :new.ID :=tempnum; end;
/

